import './userform.css';
import Table from './table.jsx'
import { useState } from 'react';
import LoadingSpinner from './LoadingSpinner.js';

function Userform() {
    let[inp,setInp]=useState([]);
    let[Loading,setLoading]=useState(false);
    let[hospital,setHospital]=useState('');
    let[b,setB]=useState('');
    function setformval(e){ 
        e.preventDefault();
        setLoading(true);
        const formData = new FormData(e.target);
        const data = {};
        formData.forEach((value, key) => {
            data[key]=value;
        });
        setInp((prev)=>[...prev,data]);
        fetch("/submit", {
            method: 'post',
            headers: {
                "Content-Type": "application/json", // Corrected content type
            },
            body: JSON.stringify(inp), // Stringify the data for JSON
        })
            .then(res => res.json())
            .then(dat => console.log(dat))
            .catch(error => console.error('Error:', error)) // Handle potential errors    
        setTimeout(() => {
            setLoading(false); // Set loading back to false when the operation is complete
          }, 500); // Adjust the timeout as needed
        }
    function fn(e){
       e.target.value==='others'?setB(1):setB('');
    }

    function placeset(e){
        if(e.target.value==='hubli')
        setHospital('hubli');
        else if(e.target.value==='banglore')
        setHospital('banglore');
        else if(e.target.value==='belagum')
        setHospital('belagum')
    }
  return (
        <div className="container">
        <h1>Past Treatment History</h1>

        <form name="myform" onSubmit={setformval}>
            <div>
                <label>Name:</label><input type='text' name='name'/>
            </div>
            <div>
                <label>ID</label> :<input type='number' name='ID'/>
            </div>
            <div>
                <label htmlFor="year">Year:</label>
                <input type="number" name="year" id="year" min="1923" max="2023" required placeholder='Enter year'/>
            </div>
            <div>
                <label htmlFor="place">Place:</label>
                <select name="place" id="place" required onChange={placeset}>
                    <option value="">--select--</option>
                    <option value="hubli">Hubli</option>
                    <option value="banglore">Banglore</option>
                    <option value="c">belgaum</option>
                    <option value="d">D</option>
                    <option value="e">E</option>
                </select>
            </div>
            <div>
                <label htmlFor="center">Center:</label>
                {hospital==='hubli'?<select name="center" id="center" required>
            <>      <option value="">--select--</option>
                    <option value='KIMMS'>KIMMS</option>
                    <option value='SDM'>SDM</option></>   </select>:''}
             
                {hospital==='banglore'?<><select name="center" id="center" required>
                 <option value="">--select--</option>
                    <option value='bang'>bang</option>
                    <option value='SDM'>apollo</option></select></>:''}

                    {hospital==='belagum'?<><select name="center" id="center" required>
                 <option value="">--select--</option>
                    <option value='kle hospital'>bang</option>
                    <option value='city hospital'>apollo</option></select></>:''}
           
                
            </div>
            <div>
                <label htmlFor="tperiod">Treatment Period:</label>
                <div id="period">
                    <input type="number" name="tperiod_value" id="tperiod" required/>
                    <select name="tperiod_unit" id="unit">
                        <option value="days">Days</option>
                        <option value="months">Months</option>
                        <option value="years">Years</option>
                    </select>
                </div>
            </div>
            <div>
                <label htmlFor="speriod">Sobriety Period:</label>
                <div id="period">
                    <input type="number" name="speriod_value" id="speriod" required/>
                    <select name="speriod_unit" id="unit">
                        <option value="days">Days</option>
                        <option value="months">Months</option>
                        <option value="years">Years</option>
                    </select>
                </div>
            </div>
            <div>
                <label htmlFor="reason">Reason for Soberness:</label>
                <div id="period">
                    <select name="reason" id="reason" required onChange={fn}>
                        <option value="">--select--</option>
                        <option>Family problems</option>
                        <option>Friends</option>
                        <option>Work-load</option>
                        <option>Breakup</option>
                        <option value="others">Others</option>
                    </select>
                    {b&&(<input type="text" name="otherReason" id="otherReason"
                        placeholder="Specify other reason"/>)}
                </div>
            </div>
            <div>
                <label htmlFor="relapse">Relapse Period:</label>
                <div id="period">
                    <input type="number" name="relapse_value" id="relapse" required/>
                    <select name="relapse_unit" id="unit">
                        <option value="days">Days</option>
                        <option value="months">Months</option>
                        <option value="years">Years</option>
                    </select>
                </div>
            </div>
            <button type="submit" className='button-71'>ADD</button>
        </form>
        {Loading?<LoadingSpinner/>: <Table data={inp}/>}
    </div>
  )
}

export default Userform;
