import React, { useState } from "react";
import Userform from "./components/userform";
import Basic from "./components/basicinfo";

function App() {
  const [status, setStatus] = useState(false);

  function f() {
    setStatus(!status);
  }

  return (
    <>
      {status && <Userform />}
      {!status&&<Basic/>}
      <button onClick={f}>Toggle Userform</button>
    </>
  );
}

export default App;
